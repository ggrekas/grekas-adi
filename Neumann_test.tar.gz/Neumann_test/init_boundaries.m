function s = init_boundaries(n)
h = 1/(n-1);
x = 0:h:1;
y = 0:h:1;

u_y_start = 0*x;
u_y_end = 2*x;
u_x_start = y.^2;
u_x_end = y.^2;

a_y_start = x;
a_y_end = x;
a_x_start = y;
a_x_end = y;


bound_u = [u_y_start, u_y_end, u_x_start, u_x_end];
bound_a = [a_y_start, a_y_end, a_x_start, a_x_end];

s = struct('u', bound_u, 'a', bound_a );