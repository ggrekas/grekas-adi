function val =a(t, x,y)
val=cos(pi*x)*cos(pi*y)+2 +x*y;
% val =1;
return;