mex calculate_rhs.c
mex TDMAsolver.c
mex my_minusTranspose.c
mex myTranspose.c
mex diags_calc.c