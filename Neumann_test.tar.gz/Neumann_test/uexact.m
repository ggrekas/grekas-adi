function u= uexact(t, x, y)
% u = exp(-t)* cos(pi*x)*cos(pi*y);
  u = exp(-t)* cos(pi*x)*cos(pi*y) + x*y*y;

return;