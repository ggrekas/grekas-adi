
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                      %
%    Example of ADI Method for 2D heat equation                        %
%                                                                      %
%          u_t = Nabla( a(t,x,y)*Nabla(u(t, x, y) ) + C*u(t,x,y) +     %
%              + f(t, c, y)                                            %                                                                      %
%    Test problme:                                                     %
%      Exact solution: u(t,x,y) = exp(-t) cos(pi*x) cos(pi*y)          %
%      Diffusion coefficient: a(t,x,y) = cos(pi*x) cos(pi*y) +2        %
%      u coefficient: C(x,y) = -(x+y + 10)                             %
%      Source term:  f(t,x,y) = -exp(-t) cos(pi*x) cos(pi*y) +         %
%      +2pi^2 exp(-t)cos(pi*x)cos(pi*y) a(t, x, y) - pi^2*exp(-t)*     %
%      *sin(pi*x)^2 cos(pi*y)^2 - pi^2 exp(-t) cos(pi*x)^2 sin(pi*y)^2 %
%      -C(t, x, y)*uexact(t, x, y);                                    % 
%                                                                      %
%    Files needed for the test:                                        %
%                                                                      %
%     test_adi.m:      This file, the main calling code.               %
%     f.m:        The file defines the f(t,x,y)                        %
%     uexact.m:    The exact solution.                                 %
%     a.m:    The file defines the Diffusion coefficient.              %
%     C.m:    The file defines u coefficient.                          %
%                                                                      %
%     Results:         n              e            ratio               %
%                     10           1.291078e-02                        %
%     t_final=0.5     20           2.962349e-03      4.3               %
%                     40           7.247843e-04      4.08              %       
%                     80           1.866732e-04      4.10              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %  clear all;
   clear variables;% close all;
   folderName ='./mexFiles/parallel'; 
   addpath(folderName);
 
   x_start = 0; x_end=1;  y_start=0; y_end=1; n =40;  tfinal = 0.5;
   
  bounds  = init_boundaries(n);
  fields_indx = [1, 2];
   m = n;
   h = (x_end - x_start)/(n-1);
   dt=h/10;   
   h1 = h*h;
   x=x_start:h:x_end;
   y=y_start:h:y_end;

%-- Initial condition:
   t = 0;
   u1= zeros(n, n);
   fi= zeros(n, n);
   ai= zeros(n,n);
   Ci= zeros(n,n);
   for i=1:m,
      for j=1:m,
         u1(i,j) = uexact(t,x(i),y(j));
         fi(i,j)= f(t, x(i), y(j));
         ai(i,j)= a(t, x(i), y(j) );
         Ci(i,j)= C(t, x(i), y(j) );
      end
   end
  
%---------- Big loop for time t --------------------------------------
k_t = fix(tfinal/dt);
u1(1)= u1(1) -1;
u1(1)= u1(1) + 1;



u= myadi(u1, ai, Ci, fi, dt, bounds, fields_indx);
for k=1:k_t
t1 = t + dt;
t2 = t + dt/2;

for i=1:m,
      for j=1:m,
         fi(i,j)= f(t2, x(i), y(j));
         ai(i,j)= a( t, x(i), y(j));
         Ci(i,j)= C(t, x(i), y(j) );
      end
end
 u= myadi(u, ai, Ci, fi, dt, bounds, fields_indx);
 t = t + dt;
%--- finish ADI method at this time level, go to the next time level.   
end       %-- Finished with the loop in time


ue= zeros(size(u1) );
  for i=1:m,
    for j=1:n,
       ue(i,j) = uexact(tfinal,x(i),y(j));
    end
  end

  
  figure(4); mesh(u);% Mesh plot of the estimated function 
  figure(5); mesh(ue)  % Mesh plot of the exact function 
  fprintf(1,'maximum absolute error =%e\n', max(max(abs(ue-u) ) ) );% Max error 
 

rmpath(folderName);