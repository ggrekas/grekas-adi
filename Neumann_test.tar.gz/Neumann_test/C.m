function [ val ] = C( t, x, y )
val = -(10 + x +y);
%val =0;
end

